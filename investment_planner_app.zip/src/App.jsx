import React, { useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

function calculateGrowth(initial, yearly, rate, years) {
  let data = [];
  let total = initial;
  for (let i = 0; i <= years; i++) {
    if (i !== 0) total += yearly;
    total *= 1 + rate;
    data.push({ age: 16 + i, value: parseFloat(total.toFixed(2)) });
  }
  return data;
}

const riskProfiles = {
  low: 0.07,
  medium: 0.10,
  high: 0.15,
};

export default function App() {
  const [initial, setInitial] = useState(1000);
  const [yearly, setYearly] = useState(2000);
  const [risk, setRisk] = useState("low");
  const [results, setResults] = useState([]);
  const [pdfOption, setPdfOption] = useState("chart+data");

  const handleCalculate = () => {
    const rate = riskProfiles[risk];
    const data = calculateGrowth(parseFloat(initial), parseFloat(yearly), rate, 9);
    setResults(data);
  };

  const downloadCSV = () => {
    const csv = ["Age,Projected Value"];
    results.forEach((row) => {
      csv.push(`${row.age},${row.value}`);
    });
    const blob = new Blob([csv.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "investment_projection.csv";
    link.click();
  };

  const printPage = () => {
    window.print();
  };

  // Dummy PDF export functions (for full version you'd use libraries like jsPDF or html2canvas)
  const downloadPDF = () => {
    alert("PDF export feature coming soon! For now, try the print button.");
  };

  return (
    <div style={{backgroundColor: "#ffe4ec", minHeight: "100vh", padding: 20, fontFamily: "Arial, sans-serif", color: "#4b4b4b"}}>
      <h1 style={{textAlign: "center", marginBottom: 20}}>💸 Investment Planner (Age 16–25)</h1>

      <div style={{maxWidth: 400, margin: "auto", backgroundColor: "#fff0f5", padding: 20, borderRadius: 10}}>
        <input
          type="number"
          placeholder="Initial Investment ($)"
          value={initial}
          onChange={(e) => setInitial(e.target.value)}
          style={{width: "100%", padding: 10, marginBottom: 10, borderRadius: 5, border: "1px solid #ff8fab"}}
        />
        <input
          type="number"
          placeholder="Yearly Contribution ($)"
          value={yearly}
          onChange={(e) => setYearly(e.target.value)}
          style={{width: "100%", padding: 10, marginBottom: 10, borderRadius: 5, border: "1px solid #ff8fab"}}
        />
        <select
          value={risk}
          onChange={(e) => setRisk(e.target.value)}
          style={{width: "100%", padding: 10, marginBottom: 10, borderRadius: 5, border: "1px solid #ff8fab"}}
        >
          <option value="low">Low Risk (7%)</option>
          <option value="medium">Medium Risk (10%)</option>
          <option value="high">High Risk (15%)</option>
        </select>

        <button
          onClick={handleCalculate}
          style={{width: "100%", padding: 10, backgroundColor: "#ff8fab", color: "white", borderRadius: 5, border: "none", cursor: "pointer"}}
        >
          Calculate
        </button>

        {results.length > 0 && (
          <>
            <button
              onClick={downloadCSV}
              style={{width: "100%", marginTop: 10, padding: 10, backgroundColor: "white", color: "#ff8fab", border: "2px solid #ff8fab", borderRadius: 5, cursor: "pointer"}}
            >
              📥 Download CSV
            </button>

            <div style={{marginTop: 20}}>
              <label>
                <input
                  type="radio"
                  checked={pdfOption === "chart+data"}
                  onChange={() => setPdfOption("chart+data")}
                  style={{marginRight: 5}}
                />
                PDF: Chart + Data
              </label>
              <br />
              <label>
                <input
                  type="radio"
                  checked={pdfOption === "chart"}
                  onChange={() => setPdfOption("chart")}
                  style={{marginRight: 5}}
                />
                PDF: Chart Only
              </label>
              <br />

              <button
                onClick={downloadPDF}
                style={{marginTop: 10, width: "100%", padding: 10, backgroundColor: "#ff8fab", color: "white", borderRadius: 5, border: "none", cursor: "pointer"}}
              >
                📄 Download PDF (Print for now)
              </button>

              <button
                onClick={printPage}
                style={{marginTop: 10, width: "100%", padding: 10, backgroundColor: "#ff8fab", color: "white", borderRadius: 5, border: "none", cursor: "pointer"}}
              >
                🖨️ Print
              </button>
            </div>
          </>
        )}
      </div>

      {results.length > 0 && (
        <div style={{maxWidth: 600, height: 300, margin: "40px auto"}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={results}>
              <XAxis dataKey="age" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#ff8fab" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}