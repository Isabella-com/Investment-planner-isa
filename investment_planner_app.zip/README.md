# Investment Planner App

This is a React app that helps you calculate investment growth with different risk levels and contributions.

### Features
- Input initial investment and yearly contributions
- Select risk level (low, medium, high)
- See projected growth chart from age 16 to 25
- Download CSV of projected values
- Print the chart and data
- Export PDF option (print is currently recommended)
- Pastel pink modern UI

### To run locally:
1. Install Node.js and npm
2. Run `npm install`
3. Run `npm start`

### To build for deployment:
Run `npm run build`